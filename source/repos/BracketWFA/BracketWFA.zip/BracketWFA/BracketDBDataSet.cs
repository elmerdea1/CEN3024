﻿namespace BracketWFA
{


    partial class BracketDBDataSet
    {
    }
}

namespace BracketWFA.BracketDBDataSetTableAdapters {
    
    
    public partial class PeopleTableAdapter {
    }
}
